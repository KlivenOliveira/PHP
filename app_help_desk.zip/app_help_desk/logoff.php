<?php
	session_start();
//	echo '<pre>';
//	print_r($_SESSION);
//	echo '<pre>';
	//remover indices do array
    //unset()
	//destruir variavel de sessao
	//session_destroy()

//	echo '<pre>';
//	print_r($_SESSION);
//	echo '<pre>';

	session_destroy(); //remova todos
	header('Location:index.php')
//	echo '<pre>';
//	print_r($_SESSION);
//	echo '<pre>';


?>