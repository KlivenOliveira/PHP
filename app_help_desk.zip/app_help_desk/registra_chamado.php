<?php
	session_start();

	//montagem texto
	$titulo = str_replace('#','-',$_POST['titulo']);	
	$categoria = str_replace('#','-',$_POST['categoria']);
	$descricao = str_replace('#','-',$_POST['descricao']);

	//abrindo arquivo
	$arquivo = fopen('arquivo.hd','a');
	
	
	//escrevendo texto
	$texto = $_SESSION['id'].'#'.$titulo.'#'. $categoria.'#'.$descricao . PHP_EOL;

	fwrite($arquivo,$texto);
	//fechadno 
	fclose($arquivo);
	header('location:abrir_chamado.php');
?>